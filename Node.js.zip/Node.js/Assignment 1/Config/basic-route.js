const express = require("express");
const user_data = require("../idex");
const router = express.Router();
const myfunction = require("../controller/userDataController");

router.get('/users', myfunction.displayPosts);
router.post('/user/search', myfunction.getPostByName); 
index.exports = router;